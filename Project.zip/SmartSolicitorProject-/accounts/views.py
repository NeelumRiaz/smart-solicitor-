from http import client
from django.http import request
from django.http import HttpResponse
from django.contrib import messages, auth
from django.contrib.auth.models import User
from .models import *
from portfolio.models import *
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

# Create your views here.

# SignIn---------------------->
def signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            messages.success(request, 'You are now logged in')
            return redirect('timeline')
        else:
            messages.error(request, 'Invalid Login Credentails')
            return redirect('signin')
    return render(request, 'accounts/sign-in.html')

# SignUp---------------------->
def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        role = request.POST['role']
        birth = request.POST['birth']
        if password == confirm_password:
            if User.objects.filter(username=username).exists():
                messages.error(request, 'Username Already Exists!')
                return redirect('signup')
            elif User.objects.filter(email=email).exists():
                messages.info(request, 'Email Already Exists!')
                return redirect('signup')
            else:
#                user = User.objects.create_user(username=username, password=password, email=email)
#                lastInsertId = (User.objects.last()).id #-----> get last id from user table
#                idSaveInProfile = Profile(user_id = lastInsertId, date_of_birth =birth, user_role = role)
#                idSaveInProfile.save()

                user = User.objects.create_user(username=username, password=password, email=email)
                user.save()

                #log user in and redirect to settings page
                user_login = auth.authenticate(username=username, password=password)
                auth.login(request, user_login)

                #create a Profile object for the new user
                user_model = User.objects.get(username=username)
                new_profile = Profile.objects.create(user=user_model, id_user=user_model.id, date_of_birth =birth, user_role = role)
                new_profile.save()

                messages.success(request, 'You are now logged in!')
                return redirect('edit')
        else:
            messages.error(request, 'Password do not match!')
            return redirect('signup')
    else:
        return render(request, 'accounts/sign-up.html')

# Forgot---------------------->
def forgot(request):
    return render(request, 'accounts/forgot.html')

# Reset---------------------->
def reset(request):
    return render(request, 'accounts/reset.html')

# Verify---------------------->
def verify(request):
    return render(request, 'accounts/verify.html')

# Success---------------------->
def success(request):
    return render(request, 'accounts/success.html')

# Error---------------------->
def error(request):
    return render(request, 'accounts/error.html')

# SignOut---------------------->
def signout(request):
	if request.method == 'POST':
		auth.logout(request)
		messages.success(request, 'You are now successfully sign out')
		return redirect('signin')
	return redirect('signin')