from django.urls import path
from . import views # . means for all

urlpatterns = [
    path('signin', views.signin, name='signin'),
    path('signup', views.signup, name='signup'),
    path('forgot', views.forgot, name='forgot'),
    path('reset', views.reset, name='reset'),
    path('verify', views.verify, name='verify'),
    path('success', views.success, name='success'),
    path('error', views.error, name='error'),
    path('signout', views.signout, name='signout'),
]