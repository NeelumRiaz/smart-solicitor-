from django.db import models
from django.contrib.auth.models import User
from django.db.models import FloatField
from portfolio.models import *
from ckeditor.fields import RichTextField
from django.utils.crypto import get_random_string
from distutils.command.upload import upload
import random

# Create your models here.

#----(CaseFile)---------------->
class CaseFile(models.Model):
    stage = (
        ('Pre action conduct', 'Pre action conduct'),
        ('Issuing the claim and exchanging statements of case', 'Issuing the claim and exchanging statements of case'),
        ('Exchange of evidence', 'Exchange of evidence'),
        ('Trial', 'Trial'),
        ('Post trial Appeal and Enforcement', 'Post trial Appeal and Enforcement'),
        ('Finalize', 'Finalize'),
        )
    courts = (
        ('District and Sessions Judge Court', 'District and Sessions Judge Court'),
        ('Civil Judge cum Assistant Sessions Judge', 'Civil Judge cum Assistant Sessions Judge'),
        ('Munsiff Court', 'Munsiff Court'),
        ('CJM Court', 'CJM Court'),
        ('MACT', 'MACT'),
        ('Industrial Tribunal Court', 'Industrial Tribunal Court'),
        ('High Court', 'High Court'),
        ('Supreme Court', 'Supreme Court'),
        ('Family Court', 'Family Court'),
        ('Supreme Court', 'Supreme Court'),
    )

    sts = (
        ('Pending', 'Pending'),
        ('Active', 'Active'),
        ('Canceled', 'Canceled'),
        ('Rejected', 'Rejected'),
        ('Won', 'Won'),
        ('Lost', 'Lost'),
        ('Appealed', 'Appealed'),
    )
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    client_id = models.IntegerField()
    case_reg_no = models.CharField(blank=True, max_length=500)
    case_title = models.CharField(blank=True, max_length=500)
    case_type = models.CharField(blank=True, max_length=500)
    case_filing_date = models.CharField(blank=True, max_length=500)
    case_act = models.CharField(blank=True, max_length=500)
    case_stage = models.CharField(choices=stage, blank=True, max_length=200)
    case_status = models.CharField(choices=sts, blank=True, max_length=15)
    case_final_amount = models.IntegerField()
    court_of = models.CharField(choices=courts, blank=True, max_length=500)
    court_address = models.CharField(blank=True, max_length=500)
    case_priority = models.CharField(blank=True, max_length=500)
    case_remarks = RichTextField()
    case_slug = models.CharField(max_length=15, blank=True, editable=False, unique=True, default="0")
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self,*args, **kwargs):
        self.case_slug = get_random_string(15).lower()
        super(CaseFile, self).save(*args, **kwargs)

    def ___str__(self):
        return self.case_reg_no

#----(CaseDocument)---------------->
class CaseDocument(models.Model):
    case = models.ForeignKey(CaseFile, on_delete=models.CASCADE)
    doc_type = models.CharField(blank=True, max_length=200)
    doc_file = models.FileField(blank=True, upload_to = 'documents/%Y/%d/')
    doc_remarks = RichTextField()
    
    def __str__(self):
        return self.doc_type

#----(CasePayment)---------------->
class CasePayment(models.Model):
    type = (
        ('Court Fee', 'Court Fee'),
        ('Document Fee', 'Document Fee'),
        ('Attestation Fee', 'Attestation Fee'),
        ('Case Installment', 'Case Installment'),
        ('Other', 'Other'),
    )

    case = models.ForeignKey(CaseFile, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    client_id = models.IntegerField()
    pay_type = models.CharField(choices=type, blank=True, max_length=200)
    pay_token = models.CharField(max_length=10, blank=True, editable=False, unique=True, default=0)
    pay_amount = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self,*args, **kwargs):
        self.pay_token = random.randint(1000000000, 9999999999)
        super(CasePayment, self).save(*args, **kwargs)


#----(Opponent Party)---------------->
class OpponentPartyDetail(models.Model):
    role = (
        ('Opponent Person', 'Opponent Person'),
        ('Opponent Solicitor', 'Opponent Solicitor'),
        ('Opponent Witness', 'Opponent Witness'),
        ('Case Person', 'Case Person'),
        ('Case Solicitor', 'Case Solicitor'),
        ('Case Witness', 'Case Witness'),
    )
    case = models.ForeignKey(CaseFile, on_delete=models.CASCADE)
    opponent_name = models.CharField(blank=True, max_length=200)
    opponent_father_name = models.CharField(blank=True, max_length=200)
    opponent_phone = models.CharField(blank=True, max_length=16)
    opponent_email = models.CharField(blank=True, max_length=100)
    opponent_addrress = models.CharField(blank=True, max_length=500)
    opponent_role = models.CharField(choices=role, blank=True, max_length=20)
    remarks = RichTextField()

    def __str__(self):
        return self.opponent_name


#----(Case Result)---------------->
class CaseResult(models.Model):
    case = models.ForeignKey(CaseFile, on_delete=models.CASCADE)
    result_description = RichTextField()
    result_file = models.FileField(blank=True, upload_to = 'documents/%Y/%d/')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.result_description

