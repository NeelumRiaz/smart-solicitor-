from ast import keyword
from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.contrib import messages, auth
from django.contrib.auth.models import User
from django.db.models import Sum, Count, Max, Min, Q
from .models import *
from portfolio.models import *
from newsfeed.models import *
from hearings.models import *
from cases.models import *
from django.contrib.auth.decorators import login_required
from itertools import chain

# Create your views here.

# List---------------------->
@login_required
def list(request):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
###======== For Current Page Function -------------------------->

    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()


    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'cases/list.html', data)

# Detail---------------------->
@login_required
def detail(request, case_slug):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
###======== For Current Page Function -------------------------->

    getCaseDetail = CaseFile.objects.get(case_slug = case_slug)
    theClientID = getCaseDetail.client_id
    theCaseID = getCaseDetail.id
    getClientDetail = Profile.objects.get(user=theClientID)
    getHearingDetail = CaseHearing.objects.filter(case_id = theCaseID).all()

    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'getCaseDetail': getCaseDetail,
        'getClientDetail': getClientDetail,
        'getHearingDetail': getHearingDetail,
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'cases/detail.html', data)

@login_required
def createNewCase(request):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
###======== For Current Page Function -------------------------->

    getMyClientList = SolicitorClientRelation.objects.filter(solicitor_id = request.user.id).all()


    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()


    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'getMyClientList': getMyClientList,
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'cases/create_case.html', data)


@login_required
def saveNewCase(request):
    if request.method == 'POST':
        client_id = request.POST['client_id']
        case_reg_no = request.POST['case_reg_no']
        case_title = request.POST['case_title']
        case_type = request.POST['case_type']
        case_filing_date = request.POST['case_filing_date']
        case_act = request.POST['case_act']
        case_stage = request.POST['case_stage']
        case_status = request.POST['case_status']
        case_final_amount = request.POST['case_final_amount']
        court_of = request.POST['court_of']
        court_address = request.POST['court_address']
        case_priority = request.POST['case_priority']
        case_remarks = request.POST['case_remarks']

        new_case  = CaseFile.objects.create(user = request.user, client_id = client_id, case_reg_no = case_reg_no, case_title = case_title, case_type = case_type, case_filing_date = case_filing_date, case_act = case_act, case_stage = case_stage, case_status = case_status, case_final_amount = case_final_amount, court_of = court_of, court_address = court_address, case_priority = case_priority, case_remarks = case_remarks, )
        new_case.save()

        return redirect('list')
    else:
        return redirect('list')