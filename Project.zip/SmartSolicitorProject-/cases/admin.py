from django.contrib import admin
from django.utils.html import format_html
from .models import *

# Register your models here.

class CaseFileAdmin(admin.ModelAdmin):
   list_display = ('id', 'case_reg_no', 'case_title', 'case_type', 'case_final_amount', 'case_slug')
   list_display_links = ('id', 'case_reg_no', 'case_title')
   search_fields = ('case_reg_no', 'case_title')
   list_filter = ('id',)
admin.site.register(CaseFile, CaseFileAdmin)
admin.site.register(CaseDocument)

class CasePaymentAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'pay_token', 'pay_amount')
    list_display_links = ('id', 'pay_token')
    search_fields = ('pay_token',)
    list_filter = ('id',)
admin.site.register(CasePayment, CasePaymentAdmin)

admin.site.register(OpponentPartyDetail)
admin.site.register(CaseResult)

#class ProductAdmin(admin.ModelAdmin):

#    list_display = ('id', 'category_id', 'product_by', 'product_title', 'product_offer_price', 'product_last_bid', 'product_status')
#    list_display_links = ('id', 'product_title')
#    search_fields = ('product_title', 'product_description')
#    list_filter = ('id',)

#    pass

#admin.site.register(Product, ProductAdmin)
