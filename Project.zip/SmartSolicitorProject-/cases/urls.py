from django.urls import path
from . import views # . means for all

urlpatterns = [
    path('list', views.list, name='list'),
    path('detail/<str:case_slug>', views.detail, name='detail'),
    path('createNewCase', views.createNewCase, name='createNewCase'),
    path('saveNewCase', views.saveNewCase, name='saveNewCase'),
]