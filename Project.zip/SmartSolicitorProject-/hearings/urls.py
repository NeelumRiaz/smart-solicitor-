from django.urls import path
from . import views # . means for all

urlpatterns = [
    path('today', views.today, name='today'),
    path('show', views.show, name='show'),
    path('add', views.add, name='add'),
    path('saveHearing', views.saveHearing, name='saveHearing'),
]