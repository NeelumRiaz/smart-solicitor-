from django.db import models
from django.contrib.auth.models import User
from portfolio.models import *
from cases.models import CaseFile
from ckeditor.fields import RichTextField

# Create your models here.

class CaseHearing(models.Model):
    status = (
        ('Pending', 'Pending'),
        ('Missed', 'Missed'),
        ('Proceed', 'Proceed'),
        )
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    case = models.ForeignKey(CaseFile, on_delete=models.CASCADE)
    client_id = models.IntegerField()
    hearing_date = models.CharField(blank=True, max_length=20)
    hearing_status = models.CharField(choices=status, max_length=15)
    hearing_summ = RichTextField()
    hearing_tag = models.CharField(blank=True, max_length=50)
    
    def ___str__(self):
        return self.hearing_date
