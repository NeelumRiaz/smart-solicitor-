from ast import keyword
from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.contrib import messages, auth
from django.contrib.auth.models import User
from django.db.models import Sum, Count, Max, Min, Q
from .models import *
from portfolio.models import *
from newsfeed.models import *
from cases.models import *
from django.contrib.auth.decorators import login_required
from itertools import chain
# Create your views here.

# Today---------------------->
@login_required
def today(request):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()
###======== For Current Page Function -------------------------->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'hearing/today.html', data)

@login_required
def add(request):
        ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    

    getMyCaseForHearing = CaseFile.objects.filter(user=request.user.id).all()
    getMyAllHearings = CaseHearing.objects.filter(user=request.user.id).all()

    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

###======== For Current Page Function -------------------------->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'getMyCaseForHearing': getMyCaseForHearing,
        'getMyAllHearings': getMyAllHearings,
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'hearing/add.html', data)

# Show---------------------->
@login_required
def show(request):
        ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)

    getMyCaseForHearing = CaseFile.objects.filter(user=request.user.id).all()
    getMyAllHearings = CaseHearing.objects.filter(user=request.user.id).all()

    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'getMyCaseForHearing': getMyCaseForHearing,
        'getMyAllHearings': getMyAllHearings,
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'hearing/show.html', data)


@login_required
def saveHearing(request):
    if request.method == 'POST':
        case_id = request.POST['case_id']
        hearing_date = request.POST['hearing_date']
        hearing_status = request.POST['hearing_status']
        hearing_summ = request.POST['hearing_summ']

        getCase = CaseFile.objects.get(id=case_id)
        client_id = getCase.client_id

        new_hearing  = CaseHearing.objects.create(user = request.user, case_id = case_id, client_id = client_id, hearing_date=hearing_date, hearing_status=hearing_status, hearing_summ=hearing_summ )
        new_hearing.save()

        return redirect('show')
    else:
        return redirect('show')