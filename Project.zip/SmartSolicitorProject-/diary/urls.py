from django.urls import path
from . import views # . means for all

urlpatterns = [
    path('references', views.references, name='references'),
    path('refsearch', views.refsearch, name='refsearch'),
    path('createRef', views.createRef, name='createRef'),

]