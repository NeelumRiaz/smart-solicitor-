from django.db import models
from django.contrib.auth.models import User
from portfolio.models import *
from ckeditor.fields import RichTextField

# Create your models here.

class SolicitorDiary(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    case_ref = RichTextField()
    order_court = models.CharField(blank=True, max_length=200)
    created_at = models.DateTimeField(auto_now_add=True)

    def ___str__(self):
        return self.case_ref
