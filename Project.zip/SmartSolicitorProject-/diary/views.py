from ast import keyword
from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.contrib import messages, auth
from django.contrib.auth.models import User
from django.db.models import Sum, Count, Max, Min, Q
from .models import *
from portfolio.models import *
from newsfeed.models import *
from cases.models import *
from django.contrib.auth.decorators import login_required
from itertools import chain
# Create your views here.

# References---------------------->
@login_required
def references(request):
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)

###======== For Current Page Function -------------------------->
    myRefDiary = SolicitorDiary.objects.filter(user = request.user).all()

    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'myRefDiary': myRefDiary,
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'diary/references.html', data)


@login_required
def createRef(request):
    if request.method == 'POST':

        case_ref = request.POST['case_ref']
        order_court = request.POST['order_court']

        new_ref = SolicitorDiary.objects.create(user=request.user, case_ref=case_ref, order_court=order_court)
        new_ref.save()

        return redirect('references')
    else:
        return redirect('references')
        

@login_required
def refsearch(request):
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

    if request.method == 'GET':
        keyword = request.GET['keyword']
        searchRef = SolicitorDiary.objects.filter(Q(order_court__icontains=keyword)|Q(case_ref__icontains=keyword)).all()

    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'searchRef': searchRef,
        'myAllCaseList': myAllCaseList, 
    }
    return render(request, 'diary/refsearch.html', data)