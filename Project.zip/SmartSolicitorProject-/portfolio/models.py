from distutils.command.upload import upload
from pyexpat import model
from tokenize import blank_re
from django.db import models
from django.contrib.auth.models import User
from django.utils.crypto import get_random_string
# Create your models here.

###---------->
class Profile(models.Model):
    gen = (
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    )
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    id_user = models.IntegerField()
    gender = models.CharField(choices=gen, max_length=10, default="male")
    father_name = models.CharField(blank=True, max_length=50)
    date_of_birth = models.CharField(blank=True, max_length=25)
    cnic = models.CharField(blank=True, max_length=15)
    phone_num = models.CharField(max_length=16)
    bio = models.CharField(blank=True, max_length=500)
    profile_img = models.ImageField(blank=True, upload_to = 'photos/%Y/%d/')
    address = models.CharField(blank=True, max_length=500)
    city = models.CharField(blank=True, max_length=50)
    countary = models.CharField(blank=True, max_length=25)
    user_token = models.CharField(max_length=10, blank=True, editable=False, unique=True, default=0)
    user_role = models.CharField(default='client', max_length=75)
    qualification = models.CharField(blank=True, max_length=50)
    position = models.CharField(blank=True, max_length=50)
    website = models.CharField(blank=True, max_length=100)
    facebook = models.CharField(blank=True, max_length=120)
    twitter = models.CharField(blank=True, max_length=120)
    youtube = models.CharField(blank=True, max_length=120)
    linkedin = models.CharField(blank=True, max_length=120)
#    Notification = models.CharField("Notification Status", default="0", max_length=1)

    def save(self,*args, **kwargs):
        self.user_token = get_random_string(10).lower()
        super(Profile, self).save(*args, **kwargs)

    def ___str__(self):
        return self.cnic

###---------->
class FollowersCount(models.Model):
    follower = models.CharField(max_length=100)
    user = models.CharField(max_length=100)

    def __str__(self):
        return self.user

###---------->
class SolicitorClientRelation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    solicitor_id = models.IntegerField()
    relations = models.CharField(default=0, max_length=2)

###---------->
class Notificiation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    notif_body = models.CharField(blank=True, max_length=340)
    is_seen = models.BooleanField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.notif_body