import imp
from tkinter import Widget
from django.core import validators
from django import forms
from django.forms import ModelForm
from .models import *

class ProfileForm(ModelForm):
    class Meta:
        model = Profile
        fields = ['father_name', 'date_of_birth', 'bio', 'cnic', 'phone_num', 'profile_img', 'qualification', 'position', 'address', 'city', 'countary', 'website', 'facebook', 'twitter', 'youtube', 'linkedin', 'gender']
#        lables = {'father_name':' ', 'date_of_birth':' ', 'bio':'', 'cnic':'', 'phone_num':'', 'profile_img':'', 'qualification':'', 'position':'', 'address':'', 'city':'', 'countary':'', 'website':'', 'facebook':'', 'twitter':'', 'youtube':'', 'linkedin':''}
        widgets = {
            'date_of_birth': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Date of Birth',
            'type': 'date',
            }),
            'father_name': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Father Name',
            }),
            'cnic': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'CNIC',
            }),
            'phone_num': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Phone No',
            }),
            'bio': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Bio',
            }),
            'profile_img': forms.FileInput(attrs={'class':'form-control center',
            'placeholder': 'Upload Your Image',
            }),
            'address': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Home Address',
            }),
            'city': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'City',
            }),
            'countary': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Countary',
            }),
            'qualification': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Qualification',
            }),
            'position': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Job Position',
            }),
            'website': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Website Link',
            }),
            'facebook': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Facebook Link',
            }),
            'twitter': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Twitter link',
            }),
            'youtube': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Youtube Link',
            }),
            'linkedin': forms.TextInput(attrs={'class':'form-control center',
            'placeholder': 'Linkedin Link',
            }),
        }