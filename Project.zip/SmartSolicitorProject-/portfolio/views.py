from ast import keyword
from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.contrib import messages, auth
from django.contrib.auth.models import User
from django.db.models import Sum, Count, Max, Min, Q
from .models import *
from portfolio.models import *
from newsfeed.models import *
from cases.models import *
from chats.models import *
from .forms import *
from django.contrib.auth.decorators import login_required
from itertools import chain


###=======(My Profile Page)=======-->
@login_required
def my(request):
###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    myPosts = CommunityPost.objects.filter(user=request.user.id)
###======== For Current Page Function -------------------------->

    getMyPost = CommunityPost.objects.filter(user=request.user.id).all().order_by('-created_at')

    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

    #----(Dictonar)--->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'getMyPost': getMyPost,
        'myAllCaseList': myAllCaseList,
        'myPosts': myPosts,
    }
    return render(request, 'portfolio/my.html', data)



###=======(Edit My Profile Page)=======-->
@login_required
def edit(request):
###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
###======== For Current Page Function -------------------------->
    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()
    
    ###---(Profile information saved from input data)
    if request.method == 'POST':
        userMainTable = User.objects.get(pk=request.user.id)
        profileTable = Profile.objects.get(user_id=request.user.id)
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']

        userMainTable.first_name = firstname      
        userMainTable.last_name = lastname     
        userMainTable.save()
        
        form = ProfileForm(request.POST, request.FILES, instance=profileTable)
        if form.is_valid():
            form.save()
            return redirect('my')
    else: 
        form = ProfileForm()
    
    ####---(Data Dictionary)--->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'form': form,
        'myAllCaseList': myAllCaseList,
    }

    return render(request, 'portfolio/edit.html', data)



###=======(User Profile Page)=======-->
@login_required
def user(request, user_token):
    userInfo = Profile.objects.get(user=request.user)
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count

    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()


    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()

    allMembers = Profile.objects.all().exclude(user=request.user)

    ###=== get detail of selected user
    getUserInfo = Profile.objects.get(user_token = user_token)
    getUserPost = CommunityPost.objects.filter(user=getUserInfo.user.id).all().order_by('-created_at')

    getUserChatModel = ChatModel.objects.filter(Q(user_a = request.user.username, user_b = getUserInfo.user.username)|Q(user_b = request.user.username, user_a = getUserInfo.user.username)).all()
    
    ###=== get follower and following of selected user
    follower = request.user.username
    user = getUserInfo.user.username
    if FollowersCount.objects.filter(follower=follower, user=user).first():
        button_text = 'Unfollow'
    else:
        button_text = 'Follow'
    user_followers = FollowersCount.objects.filter(user=getUserInfo.user.username).count
    user_following = FollowersCount.objects.filter(follower=getUserInfo.user.username).count

    ###=== get hiring options
    client = request.user.id
    solicitor = getUserInfo.user.id
    if SolicitorClientRelation.objects.filter(user=client, solicitor_id=solicitor, relations='1').first():
        button_text2 = 'Your Solicitor'
    elif SolicitorClientRelation.objects.filter(user=client, solicitor_id=solicitor, relations='0').first():
        button_text2 = 'Your Request Pending'
    else:
        button_text2 = 'Hire Solicitor for Case'
    
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=solicitor).count
    totalPost = CommunityPost.objects.filter(user=solicitor).count
    totalCase = CaseFile.objects.filter(user=solicitor).count

    #----(Dictonar)--->
    data = {
        'userInfo' : userInfo,
        'notifCount': notifCount,
        'getUserInfo': getUserInfo,
        'button_text': button_text,
        'user_followers': user_followers,
        'user_following': user_following,
        'button_text2': button_text2,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'getUserPost': getUserPost,
        'getMyFavor': getMyFavor,
        'totalRequest': totalRequest,
        'myAllCaseList': myAllCaseList,
        'getUserChatModel': getUserChatModel, 
    }
    return render(request, 'portfolio/user.html', data)

@login_required
def sendMessage(request):
    if request.method == 'POST':
        user_a = request.POST['user_a']
        textmessage = request.POST['textmessage']
        user_token = request.POST['user_token']

        mew_chat_message = ChatModel.objects.create(user_a = user_a, user_b = request.user.username, message = textmessage)
        mew_chat_message.save()
        return redirect('user/'+user_token)
    return redirect('my')

###=======(Solicitors List Page)=======-->
@login_required
def follow(request):
    if request.method == 'POST':
        follower = request.POST['follower']
        user = request.POST['user']
        user_token = request.POST['user_token']

        if FollowersCount.objects.filter(follower=follower, user=user).first():
            delete_follower = FollowersCount.objects.get(follower=follower, user=user)
            delete_follower.delete()
            return redirect('user/'+user_token)
        else:
            new_follower = FollowersCount.objects.create(follower=follower, user=user)
            new_follower.save()
            return redirect('user/'+user_token)
    else:
        return redirect('my')

@login_required
def postFavorUserProfile(request):
    if request.method == 'POST':
        username = request.user.username
        post_id = request.POST['post_id']
        user_token = request.POST['user_token']

        post = CommunityPost.objects.get(id=post_id)

        like_filter = LikePost.objects.filter(post_id=post_id, username=username).first()

        if like_filter == None:
            new_like = LikePost.objects.create(post_id=post_id, user_id = request.user.id,  username=username)
            new_like.save()
            post.no_of_likes = post.no_of_likes+1
            post.save()
            return redirect('user/'+user_token)
        else:
            like_filter.delete()
            post.no_of_likes = post.no_of_likes-1
            post.save()
            return redirect('user/'+user_token)

@login_required
def postFavorProfile(request):
    if request.method == 'GET':
        username = request.user.username
        post_id = request.GET['post_id']

        post = CommunityPost.objects.get(id=post_id)

        like_filter = LikePost.objects.filter(post_id=post_id, username=username).first()

        if like_filter == None:
            new_like = LikePost.objects.create(post_id=post_id, user_id = request.user.id,  username=username)
            new_like.save()
            post.no_of_likes = post.no_of_likes+1
            post.save()
            return redirect('my')
        else:
            like_filter.delete()
            post.no_of_likes = post.no_of_likes-1
            post.save()
            return redirect('my')

@login_required
def hireForCase(request):
    if request.method == 'POST':
        solicitor = request.POST['solicitor']
        user_token = request.POST['user_token']

        if SolicitorClientRelation.objects.filter(user=request.user, solicitor_id = solicitor).first():
            cancle_hiring = SolicitorClientRelation.objects.get(user=request.user, solicitor_id = solicitor)
            cancle_hiring.delete()
            return redirect('user/'+user_token)
        else:
            hire_for_case = SolicitorClientRelation.objects.create(user=request.user, solicitor_id = solicitor)
            hire_for_case.save()
            return redirect('user/'+user_token)
    else:
        return redirect('my')

@login_required
def acceptHiring(request):
    if request.method == 'GET':
        myclientID = request.GET['myclientID']
        relationID = request.GET['relationID']
        solicitorID = request.user.id
       
        accept_hiring = SolicitorClientRelation.objects.filter(id=relationID, user = myclientID, solicitor_id = solicitorID).update(relations='1')
#        accept_hiring.save()
        return redirect('myClients')

    else:
        return redirect('myClients')


###=======(Solicitors List Page)=======-->
@login_required
def solicitors(request):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    
###======== For Current Page Function -------------------------->

    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()


    getSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    paginator = Paginator(getSolicitors, 24)
    page = request.GET.get('page')
    allSolicitors = paginator.get_page(page)


    #----(Dictonar)--->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'totalRequest': totalRequest,
#        Current Page Variables
        'allSolicitors': allSolicitors,
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'portfolio/solicitors.html', data)



###=======(Clients List Page)=======-->
@login_required
def clients(request):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
###======== For Current Page Function -------------------------->
    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

    getClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    paginator = Paginator(getClients, 24)
    page = request.GET.get('page')
    allClients = paginator.get_page(page)


    #----(Dictonar)--->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'allClients': allClients,
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'portfolio/clients.html', data)


###=======(My Clients List Page)=======-->
@login_required
def myClients(request):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
###======== For Current Page Function -------------------------->
    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

    myClientList = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id)


    #----(Dictonar)--->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'myClientList': myClientList,
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'portfolio/myclient.html', data)


@login_required
def mySolicitors(request):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

###======== For Current Page Function -------------------------->
    
    mySolicitorID = SolicitorClientRelation.objects.get(user=request.user.id)
    mySolicitorIDis = mySolicitorID.solicitor_id
    mySolicitorList = Profile.objects.filter(user=mySolicitorIDis)
    
    #create for loop
    # get ids
    #save in array 

    #----(Dictonar)--->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'mySolicitorList': mySolicitorList,
        'myAllCaseList': myAllCaseList,
    }

    return render(request, 'portfolio/mysolicitor.html', data)

@login_required
def search(request):
###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)
    
    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

###======== For Current Page Function -------------------------->
    
    if request.method == 'GET':
        keyword = request.GET['keyword']
        username_object = User.objects.filter(Q(username__icontains=keyword)|Q(first_name__icontains=keyword)|Q(last_name__icontains=keyword))

        username_profile = []
        allMembers = []

        for users in username_object:
            username_profile.append(users.id)

        for ids in username_profile:
            profile_lists = Profile.objects.filter(id_user=ids)
            allMembers.append(profile_lists)
        
        allMembers = list(chain(*allMembers))
    
        
    #----(Dictonar)--->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'allMembers': allMembers,
        'myAllCaseList': myAllCaseList,
    }
    return render(request, 'portfolio/search.html', data)