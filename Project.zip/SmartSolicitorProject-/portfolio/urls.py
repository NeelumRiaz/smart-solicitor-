from django.urls import path
from . import views # . means for all

urlpatterns = [
    path('my', views.my, name='my'),
    path('edit', views.edit, name='edit'),
    path('user/<str:user_token>', views.user, name='user'),
    path('follow', views.follow, name='follow'),
    path('hireForCase', views.hireForCase, name='hireForCase'),
    path('acceptHiring', views.acceptHiring, name='acceptHiring'),
    path('clients', views.clients, name='clients'),
    path('solicitors', views.solicitors, name='solicitors'),
    path('myClients', views.myClients, name='myClients'),
    path('mySolicitors', views.mySolicitors, name='mySolicitors'),
    path('sendMessage', views.sendMessage, name='sendMessage'),
    path('search', views.search, name='search'),
    path('postFavorProfile', views.postFavorProfile, name='postFavorProfile'),
    path('postFavorUserProfile', views.postFavorUserProfile, name='postFavorUserProfile')
]