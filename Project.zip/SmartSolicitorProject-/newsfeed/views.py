from http import client
from django.http import request
from django.http import HttpResponse
from django.contrib import messages, auth
from django.contrib.auth.models import User
from .models import *
from portfolio.models import *
from cases.models import *
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
# Create your views here.

# TimeLine---------------------->
@login_required
def timeline(request):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count
    myPosts = CommunityPost.objects.filter(user=request.user.id)
    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)

###======== For Current Page Function -------------------------->

    getHomePost = CommunityPost.objects.filter().all().order_by('-created_at')
    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()

    #----(Dictonar)--->
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'getHomePost': getHomePost,
        'myAllCaseList': myAllCaseList,
        'myPosts': myPosts,
    }
    return render(request, 'newsfeed/timeline.html', data)


# Post---------------------->
@login_required
def post(request, post_slug):
    ###------(for Current User Profile)----->
    userInfo = Profile.objects.get(user=request.user)
    getMyFavor = LikePost.objects.filter(user_id=request.user.id).all()
    notifCount = Notificiation.objects.filter(user=request.user, is_seen='0').count
    myFollowers = FollowersCount.objects.filter(user=request.user.username).count
    myFollowing = FollowersCount.objects.filter(follower=request.user.username).count
    totalClient = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='1').count
    totalRequest = SolicitorClientRelation.objects.filter(solicitor_id=request.user.id, relations='0').count
    totalPost = CommunityPost.objects.filter(user=request.user.id).count
    totalCase = CaseFile.objects.filter(user=request.user.id).count

    # message pending
    
    allMembers = Profile.objects.all().exclude(user=request.user)
    allClients = Profile.objects.all().filter(user_role='client').exclude(user=request.user)
    allSolicitors = Profile.objects.all().filter(user_role='solicitor').exclude(user=request.user)

###======== For Current Page Function -------------------------->
    getPostDetail = CommunityPost.objects.get(id = post_slug)
    postID = str(getPostDetail.id)
    userID = getPostDetail.user_id
    getPostUser = Profile.objects.get(id_user=userID)
    getPostComments = CommunityComments.objects.filter(post_id=postID).all()

    if userInfo.user_role == 'client':
        myAllCaseList = CaseFile.objects.filter(client_id = request.user.id).all()
    elif userInfo.user_role == 'solicitor':
        myAllCaseList = CaseFile.objects.filter(user = request.user).all()
        
    data = {
        'userInfo': userInfo,
        'getMyFavor': getMyFavor,
        'notifCount': notifCount,
        'myFollowers': myFollowers,
        'myFollowing': myFollowing,
        'totalClient': totalClient,
        'totalPost': totalPost,
        'totalCase': totalCase,
        'allMembers': allMembers,
        'allClients': allClients,
        'allSolicitors': allSolicitors,
        'totalRequest': totalRequest,
#        Current Page Variables
        'getPostDetail': getPostDetail,
        'getPostUser': getPostUser,
        'getPostComments': getPostComments,
        'myAllCaseList': myAllCaseList,
    }

    return render(request, 'newsfeed/post.html', data)

@login_required
def uploadPostComm(request):
    if request.method == 'POST':

        image = request.FILES.get('image_upload')
        caption = request.POST['caption']

        new_post = CommunityPost.objects.create(user=request.user, post_img=image, post_body=caption)
        new_post.save()

        return redirect('timeline')
    else:
        return redirect('timeline')


@login_required
def uploadComment(request):
    if request.method == 'POST':
        ID = request.POST['id']
        com_body = request.POST['comment']
        post_slug = request.POST['post_slug']
        
        post = CommunityPost.objects.get(post_slug=post_slug)

        new_comment = CommunityComments.objects.create(user_id = request.user.id, post_id = ID,  com_body = com_body)
        new_comment.save()
        post.no_of_comments = post.no_of_comments+1
        post.save()
        return redirect('post/'+ID)
    return redirect('my')


@login_required
def postFavorTimeLine(request):
    if request.method == 'GET':
        username = request.user.username
        post_id = request.GET['post_id']
        post_slug = request.GET['post_slug']

        post = CommunityPost.objects.get(id=post_id)

        like_filter = LikePost.objects.filter(post_id=post_id, username=username).first()

        if like_filter == None:
            new_like = LikePost.objects.create(post_id=post_id, user_id = request.user.id,  username=username)
            new_like.save()
            post.no_of_likes = post.no_of_likes+1
            post.save()
            return redirect('timeline')
        else:
            like_filter.delete()
            post.no_of_likes = post.no_of_likes-1
            post.save()
            return redirect('timeline')

@login_required
def postFavorComments(request):
    if request.method == 'GET':
        username = request.user.username
        post_id = request.GET['post_id']
        post_slug = request.GET['post_slug']

        post = CommunityPost.objects.get(id=post_id)

        like_filter = LikePost.objects.filter(post_id=post_id, username=username).first()

        if like_filter == None:
            new_like = LikePost.objects.create(post_id=post_id, user_id = request.user.id,  username=username)
            new_like.save()
            post.no_of_likes = post.no_of_likes+1
            post.save()
            return redirect('post/'+post_id)
        else:
            like_filter.delete()
            post.no_of_likes = post.no_of_likes-1
            post.save()
            return redirect('post/'+post_id)



