from django.urls import path
from . import views # . means for all

urlpatterns = [
    path('timeline', views.timeline, name='timeline'),
    path('post/<str:post_slug>', views.post, name='post'),
    path('postFavorTimeLine', views.postFavorTimeLine, name='postFavorTimeLine'),
    path('postFavorComments', views.postFavorComments, name='postFavorComments'),
    path('uploadPostComm', views.uploadPostComm, name='uploadPostComm'),
    path('uploadComment', views.uploadComment, name='uploadComment'),
    
]