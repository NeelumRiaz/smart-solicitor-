from django.db import models
from django.contrib.auth.models import User
from portfolio.models import *
from django.utils.crypto import get_random_string
from ckeditor.fields import RichTextField
from distutils.command.upload import upload
import uuid

# Create your models here.

class CommunityPost(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post_body = RichTextField()
    post_img = models.ImageField(blank=True, upload_to='posts/%Y/%m/%d/')
    post_slug = models.CharField(max_length=15, blank=True, editable=False, unique=True, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    no_of_likes = models.IntegerField(default=0)
    no_of_comments = models.IntegerField(default=0)
    no_of_shares = models.IntegerField(default=0)
    

    pass

    def save(self,*args, **kwargs):
        self.post_slug = get_random_string(15).lower()
        super(CommunityPost, self).save(*args, **kwargs)

    def __str__(self):
        return self.post_body


class CommunityComments(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
#    post = models.ForeignKey(CommunityPost, on_delete=models.CASCADE)
    post_id = models.CharField(max_length=500)      # extra word
    com_body = RichTextField()
    com_img = models.ImageField(blank=True, upload_to='posts/%Y/%m/%d/')
    created_at = models.DateTimeField(auto_now_add=True)
    
    pass

class LikePost(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post_id = models.CharField(max_length=500)
    username = models.CharField(max_length=100)

    def __str__(self):
        return self.username
