from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class ChatModel(models.Model):
    user_a = models.CharField(max_length=100, default=None)
    user_b = models.CharField(max_length=100, default=None)
    message = models.TextField(null=True, blank=True)
    thread_name = models.CharField(null=True, blank=True, max_length=250)
    seen = models.CharField(default=0, max_length=1)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.message