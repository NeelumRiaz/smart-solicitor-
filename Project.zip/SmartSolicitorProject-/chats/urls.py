from django.urls import path
from . import views # . means for all
from chats.views import index, chatPage

urlpatterns = [
    path('<str:username>/', chatPage, name='chat'),
    path('msgs', views.msgs, name='msgs'),

]